
#define Pi 3.14159265358979
int clipping;
int ellipse(COORD centre, double rayonX, double rayonY);
int cercle(COORD centre, double rayon);

int lissajous(COORD centre, double rayonX, double rayonY, double p, double q);
